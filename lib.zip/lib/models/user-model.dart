



class User{

  final String uid;
  final String id;
  final String login;
  final String pwd;
  final String adresse;
  final String fullName;
  final String avatar;


  User({this.uid,this.id,this.login,this.pwd,this.fullName,this.adresse,this.avatar}){

  }

}