class Category{

  final String image_location;
  final  String image_caption;

  Category({
    this.image_location,
    this.image_caption
  });

}