class Product{


  final String product_name;
  final String product_picture;
  final int product_old_price;
  final int  product_price;

  Product({
    this.product_name,
    this.product_picture,
    this.product_old_price,
    this.product_price,
  });
}